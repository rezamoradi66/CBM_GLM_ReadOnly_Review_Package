/*
  Capital Budget Management — Stage 3 (DRAFT; NOT EXECUTED)
  Target: SQL Server 2022 / CapitalBudgetManagement_Lab

  Purpose:
   - Add explicit BudgetKind to Programs and MicroRequests, if absent.
   - Add one-route-per-micro-request enforcement for the financing decision.
   - Add workflow event history.
  Safety:
   - Additive only; no DROP/TRUNCATE/DELETE.
   - Run only after reviewing actual Stage 1/2 deployment and backing up the database.
   - This script intentionally refuses to run if prerequisite tables are missing.
   - No application/API connection is changed by this script.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

USE [CapitalBudgetManagement_Lab];
GO

IF DB_NAME() <> N'CapitalBudgetManagement_Lab'
    THROW 51000, 'Safety check failed: wrong database context.', 1;
GO

IF OBJECT_ID(N'app.Programs', N'U') IS NULL
    THROW 51001, 'Prerequisite app.Programs is missing. Review Stage 1 first.', 1;
IF OBJECT_ID(N'app.MicroRequests', N'U') IS NULL
    THROW 51002, 'Prerequisite app.MicroRequests is missing. Review Stage 1 first.', 1;
IF OBJECT_ID(N'app.Users', N'U') IS NULL
    THROW 51003, 'Prerequisite app.Users is missing. Review Stage 1 first.', 1;
GO

BEGIN TRY
    BEGIN TRANSACTION;

    /* Explicit separation of capital and current budget.
       Nullable initially to avoid inventing a classification for existing records.
       A controlled backfill is required before making this NOT NULL. */
    IF COL_LENGTH(N'app.Programs', N'BudgetKind') IS NULL
        ALTER TABLE app.Programs ADD BudgetKind nvarchar(20) NULL;

    IF COL_LENGTH(N'app.MicroRequests', N'BudgetKind') IS NULL
        ALTER TABLE app.MicroRequests ADD BudgetKind nvarchar(20) NULL;

    IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Programs_BudgetKind')
        ALTER TABLE app.Programs WITH CHECK ADD CONSTRAINT CK_Programs_BudgetKind
            CHECK (BudgetKind IS NULL OR BudgetKind IN (N'capital', N'current'));

    IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_MicroRequests_BudgetKind')
        ALTER TABLE app.MicroRequests WITH CHECK ADD CONSTRAINT CK_MicroRequests_BudgetKind
            CHECK (BudgetKind IS NULL OR BudgetKind IN (N'capital', N'current'));

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Programs_BudgetKind_Year_Status'
                   AND object_id = OBJECT_ID(N'app.Programs'))
        CREATE INDEX IX_Programs_BudgetKind_Year_Status
            ON app.Programs(BudgetKind, BudgetYear, StatusCode);

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_MicroRequests_BudgetKind_Program_Year'
                   AND object_id = OBJECT_ID(N'app.MicroRequests'))
        CREATE INDEX IX_MicroRequests_BudgetKind_Program_Year
            ON app.MicroRequests(BudgetKind, ProgramId, BudgetYear);

    /* One and only one financing/procurement route per micro-request.
       RouteCode is limited to the two approved paths. */
    IF OBJECT_ID(N'app.MicroRequestRouting', N'U') IS NULL
    BEGIN
        CREATE TABLE app.MicroRequestRouting
        (
            RoutingId          bigint IDENTITY(1,1) NOT NULL
                CONSTRAINT PK_MicroRequestRouting PRIMARY KEY,
            MicroRequestId     bigint NOT NULL,
            RouteCode          nvarchar(40) NOT NULL,
            DecisionNumber     nvarchar(100) NULL,
            StatusCode         nvarchar(50) NOT NULL
                CONSTRAINT DF_MicroRequestRouting_StatusCode DEFAULT (N'routed'),
            RoutedByUserId     bigint NULL,
            RoutedAtUtc        datetime2(3) NOT NULL
                CONSTRAINT DF_MicroRequestRouting_RoutedAtUtc DEFAULT (SYSUTCDATETIME()),
            Notes              nvarchar(1000) NULL,
            RowVer             rowversion NOT NULL,
            CONSTRAINT UQ_MicroRequestRouting_MicroRequest UNIQUE (MicroRequestId),
            CONSTRAINT FK_MicroRequestRouting_MicroRequest
                FOREIGN KEY (MicroRequestId) REFERENCES app.MicroRequests(MicroRequestId),
            CONSTRAINT FK_MicroRequestRouting_User
                FOREIGN KEY (RoutedByUserId) REFERENCES app.Users(UserId),
            CONSTRAINT CK_MicroRequestRouting_RouteCode
                CHECK (RouteCode IN (N'purchase_request', N'contractor_supply'))
        );
        CREATE INDEX IX_MicroRequestRouting_Route_Status_Date
            ON app.MicroRequestRouting(RouteCode, StatusCode, RoutedAtUtc);
    END;

    /* Append-only workflow history. EntityType/EntityId intentionally supports
       both program-level and micro-request-level events; the backend must validate IDs. */
    IF OBJECT_ID(N'app.WorkflowEvents', N'U') IS NULL
    BEGIN
        CREATE TABLE app.WorkflowEvents
        (
            WorkflowEventId    bigint IDENTITY(1,1) NOT NULL
                CONSTRAINT PK_WorkflowEvents PRIMARY KEY,
            EntityType          nvarchar(30) NOT NULL,
            EntityId            bigint NOT NULL,
            EventCode           nvarchar(80) NOT NULL,
            FromStatus          nvarchar(50) NULL,
            ToStatus            nvarchar(50) NULL,
            ActorUserId         bigint NULL,
            OccurredAtUtc       datetime2(3) NOT NULL
                CONSTRAINT DF_WorkflowEvents_OccurredAtUtc DEFAULT (SYSUTCDATETIME()),
            Comment             nvarchar(2000) NULL,
            DetailsJson         nvarchar(max) NULL,
            CorrelationId       uniqueidentifier NULL,
            CONSTRAINT FK_WorkflowEvents_Actor
                FOREIGN KEY (ActorUserId) REFERENCES app.Users(UserId),
            CONSTRAINT CK_WorkflowEvents_EntityType
                CHECK (EntityType IN (N'program', N'micro_request')),
            CONSTRAINT CK_WorkflowEvents_DetailsJson
                CHECK (DetailsJson IS NULL OR ISJSON(DetailsJson) = 1)
        );
        CREATE INDEX IX_WorkflowEvents_Entity_Time
            ON app.WorkflowEvents(EntityType, EntityId, OccurredAtUtc);
        CREATE INDEX IX_WorkflowEvents_Actor_Time
            ON app.WorkflowEvents(ActorUserId, OccurredAtUtc);
    END;

    IF OBJECT_ID(N'app.SchemaVersion', N'U') IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM app.SchemaVersion WHERE VersionCode = N'LAB-FOUNDATION-3-DRAFT')
    BEGIN
        INSERT INTO app.SchemaVersion(VersionCode, Description, AppliedAtUtc, AppliedBy)
        VALUES
        (N'LAB-FOUNDATION-3-DRAFT',
         N'Draft schema for budget-kind separation, one-route-per-micro-request, and workflow event history.',
         SYSUTCDATETIME(), ORIGINAL_LOGIN());
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

/* Post-run verification query; run only if the migration has been approved and executed. */
SELECT s.name AS SchemaName, t.name AS TableName
FROM sys.tables AS t
JOIN sys.schemas AS s ON s.schema_id = t.schema_id
WHERE s.name = N'app'
  AND t.name IN (N'Programs', N'MicroRequests', N'MicroRequestRouting', N'WorkflowEvents')
ORDER BY t.name;
GO
