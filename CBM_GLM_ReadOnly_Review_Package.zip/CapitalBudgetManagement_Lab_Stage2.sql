/*
    Capital Budget Management - Stage 2
    Target database: CapitalBudgetManagement_Lab
    Purpose: add roles and core budget reference/ledger tables.
    Safety: additive only; does not drop or truncate existing objects.
    Review this script before execution. It has NOT been executed by ChatGPT.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO
USE [CapitalBudgetManagement_Lab];
GO
IF DB_NAME() <> N'CapitalBudgetManagement_Lab'
    THROW 51000, 'Safety check failed: wrong database context.', 1;
GO
BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'app.Roles', N'U') IS NULL
    BEGIN
        CREATE TABLE app.Roles
        (
            RoleId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Roles PRIMARY KEY,
            RoleCode nvarchar(50) NOT NULL,
            RoleName nvarchar(200) NOT NULL,
            Description nvarchar(500) NULL,
            IsSystemRole bit NOT NULL CONSTRAINT DF_Roles_IsSystemRole DEFAULT (1),
            IsActive bit NOT NULL CONSTRAINT DF_Roles_IsActive DEFAULT (1),
            CreatedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_Roles_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
            CONSTRAINT UQ_Roles_RoleCode UNIQUE (RoleCode)
        );
    END;

    MERGE app.Roles AS tgt
    USING (VALUES
        (N'admin', N'مدیر سایت', N'مدیریت سامانه'),
        (N'applicant', N'متقاضی', N'ثبت و پیگیری درخواست'),
        (N'committer', N'متعهد', N'بررسی مرحله تعهد'),
        (N'senior', N'مدیر ارشد', N'بررسی مدیریتی'),
        (N'ceo', N'مدیرعامل', N'بررسی و تأیید مدیرعامل'),
        (N'budget', N'مسئول کنترل بودجه سرمایه‌ای', N'کنترل بودجه سرمایه‌ای'),
        (N'budget_cur', N'مسئول کنترل بودجه جاری', N'کنترل بودجه جاری')
    ) AS src(RoleCode, RoleName, Description)
      ON tgt.RoleCode = src.RoleCode
    WHEN NOT MATCHED BY TARGET THEN
      INSERT (RoleCode, RoleName, Description)
      VALUES (src.RoleCode, src.RoleName, src.Description);

    IF OBJECT_ID(N'app.UserRoles', N'U') IS NULL
    BEGIN
        CREATE TABLE app.UserRoles
        (
            UserRoleId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_UserRoles PRIMARY KEY,
            UserId bigint NOT NULL,
            RoleId int NOT NULL,
            IsActive bit NOT NULL CONSTRAINT DF_UserRoles_IsActive DEFAULT (1),
            AssignedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_UserRoles_AssignedAtUtc DEFAULT (SYSUTCDATETIME()),
            AssignedByUserId bigint NULL,
            CONSTRAINT FK_UserRoles_Users FOREIGN KEY (UserId) REFERENCES app.Users(UserId),
            CONSTRAINT FK_UserRoles_Roles FOREIGN KEY (RoleId) REFERENCES app.Roles(RoleId),
            CONSTRAINT FK_UserRoles_AssignedBy FOREIGN KEY (AssignedByUserId) REFERENCES app.Users(UserId),
            CONSTRAINT UQ_UserRoles_User_Role UNIQUE (UserId, RoleId)
        );
    END;

    IF OBJECT_ID(N'app.BudgetYears', N'U') IS NULL
    BEGIN
        CREATE TABLE app.BudgetYears
        (
            BudgetYearId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BudgetYears PRIMARY KEY,
            YearValue int NOT NULL,
            IsActive bit NOT NULL CONSTRAINT DF_BudgetYears_IsActive DEFAULT (1),
            IsClosed bit NOT NULL CONSTRAINT DF_BudgetYears_IsClosed DEFAULT (0),
            Notes nvarchar(500) NULL,
            CreatedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_BudgetYears_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
            UpdatedAtUtc datetime2(3) NULL,
            RowVer rowversion NOT NULL,
            CONSTRAINT UQ_BudgetYears_YearValue UNIQUE (YearValue),
            CONSTRAINT CK_BudgetYears_YearValue CHECK (YearValue BETWEEN 1300 AND 1600)
        );
    END;

    IF OBJECT_ID(N'app.BudgetHeads', N'U') IS NULL
    BEGIN
        CREATE TABLE app.BudgetHeads
        (
            BudgetHeadId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BudgetHeads PRIMARY KEY,
            SourceId nvarchar(100) NULL,
            HeadCode nvarchar(100) NULL,
            Title nvarchar(500) NOT NULL,
            ProjectNo nvarchar(100) NULL,
            BudgetKind nvarchar(20) NULL,
            IsActive bit NOT NULL CONSTRAINT DF_BudgetHeads_IsActive DEFAULT (1),
            SortOrder int NOT NULL CONSTRAINT DF_BudgetHeads_SortOrder DEFAULT (0),
            ExtraJson nvarchar(max) NULL,
            CreatedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_BudgetHeads_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
            UpdatedAtUtc datetime2(3) NULL,
            RowVer rowversion NOT NULL,
            CONSTRAINT CK_BudgetHeads_BudgetKind CHECK (BudgetKind IS NULL OR BudgetKind IN (N'capital', N'current')),
            CONSTRAINT CK_BudgetHeads_ExtraJson CHECK (ExtraJson IS NULL OR ISJSON(ExtraJson) = 1)
        );
        CREATE UNIQUE INDEX UX_BudgetHeads_SourceId ON app.BudgetHeads(SourceId) WHERE SourceId IS NOT NULL;
        CREATE INDEX IX_BudgetHeads_Kind_Active ON app.BudgetHeads(BudgetKind, IsActive, SortOrder);
    END;

    IF OBJECT_ID(N'app.BudgetEnvelopes', N'U') IS NULL
    BEGIN
        CREATE TABLE app.BudgetEnvelopes
        (
            BudgetEnvelopeId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BudgetEnvelopes PRIMARY KEY,
            BudgetYearId bigint NOT NULL,
            BudgetKind nvarchar(20) NULL,
            Title nvarchar(300) NOT NULL,
            Amount decimal(19,4) NOT NULL,
            EffectiveDateJalali nvarchar(20) NULL,
            Notes nvarchar(1000) NULL,
            SourceId nvarchar(100) NULL,
            CreatedByUserId bigint NULL,
            CreatedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_BudgetEnvelopes_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
            RowVer rowversion NOT NULL,
            CONSTRAINT FK_BudgetEnvelopes_Year FOREIGN KEY (BudgetYearId) REFERENCES app.BudgetYears(BudgetYearId),
            CONSTRAINT FK_BudgetEnvelopes_CreatedBy FOREIGN KEY (CreatedByUserId) REFERENCES app.Users(UserId),
            CONSTRAINT CK_BudgetEnvelopes_Kind CHECK (BudgetKind IS NULL OR BudgetKind IN (N'capital', N'current')),
            CONSTRAINT CK_BudgetEnvelopes_Amount CHECK (Amount >= 0)
        );
        CREATE INDEX IX_BudgetEnvelopes_Year_Kind ON app.BudgetEnvelopes(BudgetYearId, BudgetKind, CreatedAtUtc);
    END;

    IF OBJECT_ID(N'app.BudgetCeilings', N'U') IS NULL
    BEGIN
        CREATE TABLE app.BudgetCeilings
        (
            BudgetCeilingId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BudgetCeilings PRIMARY KEY,
            BudgetYearId bigint NOT NULL,
            BudgetHeadId bigint NOT NULL,
            Amount decimal(19,4) NOT NULL,
            Notes nvarchar(1000) NULL,
            SourceId nvarchar(100) NULL,
            CreatedByUserId bigint NULL,
            CreatedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_BudgetCeilings_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
            UpdatedAtUtc datetime2(3) NULL,
            RowVer rowversion NOT NULL,
            CONSTRAINT FK_BudgetCeilings_Year FOREIGN KEY (BudgetYearId) REFERENCES app.BudgetYears(BudgetYearId),
            CONSTRAINT FK_BudgetCeilings_Head FOREIGN KEY (BudgetHeadId) REFERENCES app.BudgetHeads(BudgetHeadId),
            CONSTRAINT FK_BudgetCeilings_CreatedBy FOREIGN KEY (CreatedByUserId) REFERENCES app.Users(UserId),
            CONSTRAINT CK_BudgetCeilings_Amount CHECK (Amount >= 0)
        );
        CREATE INDEX IX_BudgetCeilings_Year_Head ON app.BudgetCeilings(BudgetYearId, BudgetHeadId);
    END;

    IF OBJECT_ID(N'app.ManualBudgetAllocations', N'U') IS NULL
    BEGIN
        CREATE TABLE app.ManualBudgetAllocations
        (
            ManualBudgetAllocationId bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ManualBudgetAllocations PRIMARY KEY,
            BudgetYearId bigint NOT NULL,
            BudgetHeadId bigint NOT NULL,
            UnitId bigint NOT NULL,
            Amount decimal(19,4) NOT NULL,
            Notes nvarchar(1000) NULL,
            SourceId nvarchar(100) NULL,
            CreatedByUserId bigint NULL,
            CreatedAtUtc datetime2(3) NOT NULL CONSTRAINT DF_ManualBudgetAllocations_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
            UpdatedAtUtc datetime2(3) NULL,
            RowVer rowversion NOT NULL,
            CONSTRAINT FK_ManualBudgetAllocations_Year FOREIGN KEY (BudgetYearId) REFERENCES app.BudgetYears(BudgetYearId),
            CONSTRAINT FK_ManualBudgetAllocations_Head FOREIGN KEY (BudgetHeadId) REFERENCES app.BudgetHeads(BudgetHeadId),
            CONSTRAINT FK_ManualBudgetAllocations_Unit FOREIGN KEY (UnitId) REFERENCES app.Units(UnitId),
            CONSTRAINT FK_ManualBudgetAllocations_CreatedBy FOREIGN KEY (CreatedByUserId) REFERENCES app.Users(UserId),
            CONSTRAINT CK_ManualBudgetAllocations_Amount CHECK (Amount >= 0)
        );
        CREATE INDEX IX_ManualBudgetAllocations_Year_Unit ON app.ManualBudgetAllocations(BudgetYearId, UnitId);
        CREATE INDEX IX_ManualBudgetAllocations_Year_Head ON app.ManualBudgetAllocations(BudgetYearId, BudgetHeadId);
    END;

    /* Backfill the existing single RoleCode into the multi-role table. */
    INSERT INTO app.UserRoles (UserId, RoleId)
    SELECT u.UserId, r.RoleId
    FROM app.Users AS u
    INNER JOIN app.Roles AS r ON r.RoleCode = u.RoleCode
    WHERE u.RoleCode IS NOT NULL
      AND NOT EXISTS
      (SELECT 1 FROM app.UserRoles ur WHERE ur.UserId = u.UserId AND ur.RoleId = r.RoleId);

    IF NOT EXISTS (SELECT 1 FROM app.SchemaVersion WHERE VersionCode = N'LAB-FOUNDATION-2')
    BEGIN
        INSERT INTO app.SchemaVersion (VersionCode, Description, AppliedAtUtc, AppliedBy)
        VALUES
        (N'LAB-FOUNDATION-2',
         N'Additive roles and core budget reference/ledger tables; existing Stage 1 tables retained.',
         SYSUTCDATETIME(), ORIGINAL_LOGIN());
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO

SELECT s.name AS SchemaName, t.name AS TableName
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id = t.schema_id
WHERE s.name = N'app'
AND t.name IN (N'Roles', N'UserRoles', N'BudgetYears', N'BudgetHeads',
               N'BudgetEnvelopes', N'BudgetCeilings', N'ManualBudgetAllocations')
ORDER BY t.name;
GO

SELECT VersionCode, Description, AppliedAtUtc, AppliedBy
FROM app.SchemaVersion
WHERE VersionCode IN (N'LAB-FOUNDATION-1', N'LAB-FOUNDATION-2')
ORDER BY AppliedAtUtc;
GO
