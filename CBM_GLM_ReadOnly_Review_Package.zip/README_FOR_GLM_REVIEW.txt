Capital Budget Management (CBM) — Technical Review Package

Purpose: read-only technical audit and field-by-field mapping before further backend/database work.

Included files:
1. Capital_Budget_Management_Stabilized_v3_1_1(1).html — current HTML application reference
2. CapitalBudgetManagement_Lab_Stage1.sql — SQL Stage 1 draft/reference
3. CapitalBudgetManagement_Lab_Stage2.sql — SQL Stage 2 draft/reference
4. CapitalBudgetManagement_Lab_Stage3_DRAFT_NOT_EXECUTED.sql — Stage 3 draft, NOT EXECUTED

IMPORTANT:
- Do not execute any SQL script.
- Do not modify or overwrite the original HTML or SQL files.
- Treat Stage 3 strictly as a draft requiring review.
- Identify findings with exact file names and line numbers where possible.
- Distinguish confirmed issues from assumptions or recommendations.
- The current HTML uses browser localStorage/sessionStorage; do not treat browser-side roles/session as server-side security.
- Future architecture target: ASP.NET Core Web API + SQL Server 2022 + IIS on the internal network.
- The design must support both capital and current budgets, separate reporting/controls, and at most one next route per micro-request (purchase request OR contractor supply).
- Return a detailed Markdown report and an Excel field/table mapping if supported.
